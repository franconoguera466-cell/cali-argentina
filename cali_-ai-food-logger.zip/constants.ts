
export const DAILY_CALORIE_GOAL = 2200;
